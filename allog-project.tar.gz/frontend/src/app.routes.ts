import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { QueryComponent } from './app/weather/query/query.component'; 
import { InsertComponent} from './app/weather/insert/insert.component'; 
import { HomeComponent } from './app/home/home.component';
 
const appRoutes: Routes = [
    { path: 'home',                    component: HomeComponent },
    { path: '',                        component: HomeComponent },
    { path: 'query-weather',         component: QueryComponent },
    { path: 'insert-weather',         component: InsertComponent },
    { path: 'insert-weather/:id', component: InsertComponent }
 
];
 
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);