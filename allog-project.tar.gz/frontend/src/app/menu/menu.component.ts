import { Component } from '@angular/core';

@Component({
  selector: 'app-entrevista-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {

}