export class ConfigService {

    private urlService: string;
    private urlWeather: string;
    private apiKey: string;

    constructor() {
        this.apiKey = 'bbf0e200fb16a16391ee74f3cddf31c8';
        this.urlService = 'http://127.0.0.1:3000';
        this.urlWeather = 'http://localhost:4200/apiweather/data/2.5/weather?q=';
    }

    getUrlService(): string {
        return this.urlService;
    }

    getUrlWeather(city: string): string {
        return this.urlWeather + city + '&appid=' + this.apiKey;
    }
}