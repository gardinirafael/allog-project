export class Weather {
    id: number;
    city: string;
    date: string;
    temp_max: string
    observation: string;
    temp_min:string;
    temp: string;
    humidity: string;
}
