export class Response {
    codigo: number;
    mensagem: string;
}