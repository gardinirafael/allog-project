import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Headers } from '@angular/http';
import { RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Weather } from '../services/weather';
import { ConfigService } from './config.service';

@Injectable()
export class WeatherService {

    private baseUrlService: string = '';
    private headers: Headers;
    private options: RequestOptions;
    private configService: ConfigService;

    constructor(private http: Http, private cs: ConfigService) {
        this.configService = cs;
        this.baseUrlService = cs.getUrlService() + '/weather/';
        this.headers = new Headers({ 'Content-Type': 'application/json;charset=UTF-8' });
        this.options = new RequestOptions({ headers: this.headers });
    }

    getWeatherFromAPI(city: string) {
        return this.http.get(this.configService.getUrlWeather(city), this.options).map(res => res.json());
    }

    getWeathers() {
        return this.http.get(this.baseUrlService, this.options).map(res => res.json());
    }

    addWeather(weather: Weather) {
        return this.http.post(this.baseUrlService, JSON.stringify(weather), this.options).map(res => res.json());
    }

    deleteWeather(id: number) {
        return this.http.delete(this.baseUrlService + id).map(res => res.json());
    }

    getWeather(id: number) {
        return this.http.get(this.baseUrlService + id).map(res => res.json());
    }

    updateWeather(weather: Weather) {
        return this.http.put(this.baseUrlService, JSON.stringify(weather), this.options).map(res => res.json());
    }
}