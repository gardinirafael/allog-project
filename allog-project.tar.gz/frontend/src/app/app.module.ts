import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component';
import { QueryComponent } from './weather/query/query.component';
import { InsertComponent } from './weather/insert/insert.component';

import { routing } from './../app.routes'

import { ConfigService} from './services/config.service';
import { WeatherService} from './services/weather.service';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    HomeComponent,
    QueryComponent,
    InsertComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    routing
  ],
  providers: [ConfigService, WeatherService],
  bootstrap: [AppComponent]
})
export class AppModule { }
