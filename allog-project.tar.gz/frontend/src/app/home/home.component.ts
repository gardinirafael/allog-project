import { Component } from '@angular/core';

@Component({
     selector: 'app-home',
     templateUrl: './home.component.html'
})
export class HomeComponent {
     private mensagem: string = "Teste Entrevista Allog (Consulta API clima) - Rafael Angelo Gardini - gardini.rafael@gmail.com.";
}