import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WeatherService } from '../../services/weather.service';
import { Weather } from '../../services/weather';
import { Response } from '../../services/response';

@Component({
  selector: 'app-query-weather',
  templateUrl: './query.component.html',
  styleUrls: ["./query.component.css"]
})
export class QueryComponent implements OnInit {

  private weathers: Weather[] = new Array();
  private titulo: string;

  constructor(private weatherService: WeatherService, private router: Router) {

  }

  ngOnInit() {
    this.titulo = "Registros Cadastrados";
    this.weatherService.getWeathers().subscribe(res => this.weathers = res);
  }

  delete(id: number, index: number): void {
    if (confirm("Deseja realmente excluir esse registro?")) {

      this.weatherService.deleteWeather(id).subscribe(response => {

        let res: Response = <Response>response;

        alert('Registro excluido');

        this.weatherService.getWeathers().subscribe(res => this.weathers = res);
      },
        (erro) => {
          alert(erro);
        });
    }
  }

  edit(id: number): void {
    this.router.navigate(['/insert-weather', id]);
  }
}