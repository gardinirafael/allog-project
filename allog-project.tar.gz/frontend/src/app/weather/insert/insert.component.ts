import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { WeatherService } from '../../services/weather.service';
import { Weather } from '../../services/weather';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-cadastro-weather',
  templateUrl: './insert.component.html',
  styleUrls: ["./insert.component.css"]
})
export class InsertComponent implements OnInit {

  private titulo: string;
  private weather: Weather = new Weather();

  constructor(private weatherService: WeatherService, private router: Router, private activatedRoute: ActivatedRoute) {

  }

  ngOnInit() {

    this.activatedRoute.params.subscribe(parametro => {

      if (parametro["id"] == undefined) {

        this.titulo = "Novo Clima";
      }
      else {

        this.titulo = "Editar Cadastro de Previsão";
        this.weatherService.getWeather(Number(parametro["id"])).subscribe(res => this.weather = res);
      }
    });
  }

  convertTempToCelsius(num: number): string {
    let n: number;
    n = num - 273, 15;
    return parseFloat(n.toString()).toFixed(2);
  }

  doWeatherOps(): void {

    let num: number;

    if (document.activeElement.id == "find") {
      this.weatherService.getWeatherFromAPI(this.weather.city).subscribe((res: any) => {
        this.weather.date = formatDate(new Date(), 'yyyy-MM-dd', 'en');
        this.weather.temp = this.convertTempToCelsius(res.main.temp);
        this.weather.temp_min = this.convertTempToCelsius(res.main.temp_min);
        this.weather.temp_max = this.convertTempToCelsius(res.main.temp_max);
        this.weather.humidity = res.main.humidity;
        this.weather.observation = res.weather[0].main + ' - ' + res.weather[0].description
      }
        ,
        (erro) => {
          alert("Erro ao comunicar com API");
        });
    }
    else if (document.activeElement.id == "save") {
      this.weatherService.addWeather(this.weather).subscribe(response => {

        let res: Response = <Response>response;

        alert('Registro cadastrado');
        this.weather = new Weather();
      },
        (erro) => {
          alert("Erro ao cadastrar");
        });
    }
  }
}