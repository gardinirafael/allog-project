const proxy = [
    {
      context: '/apiweather',
      target: 'http://api.openweathermap.org',
      pathRewrite: {'^/apiweather' : ''}
    }
  ];
  
  module.exports = proxy;