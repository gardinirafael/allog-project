var express = require('express');
var App = express.Router();
var Weather = getmodule('api/weather');

/* GET home page. */
App.route('/weather')
  .get(Weather.list)
  .post(Weather.create);

App.route('/weather/:id')
  .get(Weather.getById)
  .put(Weather.update)
  .delete(Weather.delete);

module.exports = App; 